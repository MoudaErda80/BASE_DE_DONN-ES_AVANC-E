
import javax.persistence.*;
import java.util.*;

public class Test {

	public static void main(String[] args) {
		
		// Our object
		Student s;
		Person p;
		Course c;
		
		
		//Open DB
		//Create a new DB if it doesn't exist
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/Student.odb");		
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		
		// construct our class "person"
		p = new Person("Boussa","Steve","Junior","29/02/2000",'M');
		em.persist(p);
		p = new Person("Nde","Tsapi","Roland","20/08/2000",'M');
		em.persist(p);
		p = new Person("Roze","Net","Fill","08/12/2003",'F');
		em.persist(p);
		c = new Course("INF345","Advanced Data Base");
		
		// same for "course"
		

		em.getTransaction().commit();
		em.getTransaction().begin();
		Query query_person_count = em.createQuery("SELECT COUNT(p) FROM Person p");
		Query query_person_select_all = em.createQuery("SELECT p FROM Person p");
		Query query_list_courses = em.createQuery("SELECT c FROM Course c");
		
		System.out.println("Total Students: " + query_person_count.getSingleResult());
		System.out.println("Students Full Details :  " + query_person_select_all.getResultList());
		System.out.println("`\n");;
		System.out.println("List of my course : " + query_list_courses.getResultList());
		
		em.createQuery("delete from Person p").executeUpdate();
		em.getTransaction().commit();
	}
}
