

import java.util.*;
import javax.persistence.*;

	
@Entity
public class Module{
	
	//Attributes
	 private String ModuleCode;
	 private String description;
	 private int CreditHour;
	 
	public Module(String ModuleCode, String description, int CreditHour) {
		this.ModuleCode = ModuleCode;
		this. description =  description;
		CreditHour = CreditHour;
	}
	
	public String getModuleCode() {
		return ModuleCode;
	}
	
	public String getdescription() {
		return description;
	}
	
	public int getCreditHour() {
		return CreditHour;
	}
	
	//Methode .... 
	
	
	
	//Relationship with Course, Student and Lecturer
	@ManyToOne Course course;
	@ManyToOne Student student;
	@ManyToOne Lecturer lecturer;
	
	
	
}
