
import java.util.*;
import javax.persistence.*;

	
@Entity
public class Department{
	
	//Attributes
	 private String deptNum;
	 private String Name;
	 
	public Department(String deptNum,String Name) {
		this.deptNum = deptNum;
		this. Name =  Name;
	}
	
	//Getters
	
	public String getdeptNum() {
		return deptNum;
	}
	
	public String getName() {
		return Name;
	}
	
	
	//Methode .....
	
	
	//Relationship with Course, Adress and Lecturer
		@ManyToOne Course course;
		@ManyToOne Adress adress;
		@ManyToOne Lecturer lecturer;

}
