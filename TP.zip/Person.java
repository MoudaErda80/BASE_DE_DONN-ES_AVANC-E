
import java.util.*;
import javax.persistence.*;

	
@Entity
public class Person{
	
	// Define public attributes ....
	
	private String first_Name;
	private String middle_Name;
	private String last_Name;
	
	private String birthDate;
	private char gender;
	
	// Constructor
	public Person(String first_Name,String middle_Name,String last_Name,String birthDate,char gender) {
		this.first_Name = first_Name;
		this. middle_Name =  middle_Name;
		this.last_Name = last_Name;
        this.birthDate = birthDate;
        this.gender = gender;
	}
	
	//Getters
	public String getfirst_Name(){
		return first_Name;
	}
	
	public String getmiddle_Name(){
		return middle_Name;
	}
	
	public String getlast_Name(){
		return last_Name;
	}
	
	public String getbirthDate(){
		return birthDate;
	}
	
	public char getgender(){
		return gender;
	}
	
	
	@Override
	public String toString() {
		return String.format("(first_Name: %s, middle_Name: %s, last_Name: %s,birthDate: %s,gender: %s)", this.first_Name, this.middle_Name,this.last_Name,this.birthDate,this.gender);
	}
	
	// Method ...
	
	public Integer age() {
		return 21;
	}
	
	public String ChangeAdress(String newAdd) {
        newAdd = "Dang, in front Total Station";
		return newAdd;
	}

	//Relationship with Passport, Adress, Lecturer
	@ManyToOne Person person;
	@ManyToOne Passport passport;
	@ManyToOne Lecturer lecturer;
	
	
}
