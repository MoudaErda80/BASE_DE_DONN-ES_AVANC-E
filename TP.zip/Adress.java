

import java.util.*;
import javax.persistence.*;

@Entity
public class Adress {
	
	//Define Attributes ...
	@Id
	private String Post_Code;
	
	
	private char AdressType;
	private String House_Number;
	private String Street;
	private String Town;
	private String Post_Country;
	
	//Constructor ...
	public Adress(char AdressType,String House_Number,String Street,String Town,String Post_Code,String Post_Country) {
		this.AdressType = AdressType;
		this.House_Number = House_Number;
		this.Street = Street;
		this.Town = Town;
		this.Post_Code = Post_Code;
	}
	
	//Getters
	public String getPost_Code() {
		return Post_Code;
	}
	
	public char getAdressType() {
		return AdressType;
	}
	
	public String getHouse_Number() {
		return House_Number;
	}
	
	public String getStreet() {
		return Street;
	}
	
	public String getTown() {
		return Town;
	}
	
	public String getPost_Country() {
		return Post_Country;
	}
	
	//Relationship with Person and Department
	@ManyToOne Person person;
	@ManyToOne Department department;
	
}
