
import java.util.*;
import javax.persistence.*;

@Entity
public class Student extends Person{

	private String RegNUM;
	private String Major;
		

	public Student(String first_Name,String middle_Name,String last_Name,String birthDate,char gender) {
		super(first_Name, middle_Name, last_Name,birthDate,gender);
		this.RegNUM = RegNUM;
		this.Major = Major;
	}

	public String getRegNUM() {
		return RegNUM;
	}
	
	public String getMajor() {
		return Major;
	}
	
	@Override
	public String toString() {
		return String.format("(RegNUM: %s, Major: %s)", this.RegNUM, this.Major);
	}
	
	// Methode
	public Boolean Register() {
		return false;
	}

	public Boolean takeModule() {
		return false;
	}
	
	//Relationship with Course, Module and Lecturer
	@ManyToOne Course course;
	@ManyToOne Module module;
	@ManyToOne Lecturer lecturer;
	
}
