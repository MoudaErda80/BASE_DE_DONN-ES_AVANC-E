

import java.util.*;
import javax.persistence.*;

	
@Entity
public class Course{
	
	//Attributes
     @Id private String CourseCode;
     private String name;
         
	public Course(String CourseCode, String name) {
		this.CourseCode = CourseCode;
		this.name = name;
	}
	
	//Getter
	public String getCourseCode(){
		return CourseCode;
	}
	
	public String getname() {
		return name;
	}
	
	
	//Methode .... 
	
	@Override
	public String toString() {
		return String.format("(CourseCode: %s, name: %s)", this.CourseCode, this.name);
	}
	
	
	
	//Relationship with Module, Student and Department
		@ManyToOne Module module;
		@ManyToOne Student student;
		@ManyToOne Department department;
	
}
