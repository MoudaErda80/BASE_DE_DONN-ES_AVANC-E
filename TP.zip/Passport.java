

import java.util.*;
import javax.persistence.*;

@Entity
public class Passport {
	
	// Define Attribute
	
	private String PassportNum;
	private String Nationality;
	private Date IssueDate;
	private Date ExpiryDate;
	
	// Constructor
	public Passport(String PassportNum,String Nationality,Date IssueDate,Date ExpiryDate) {
		
		this.PassportNum = PassportNum;
		this.Nationality = Nationality;
		this.IssueDate = IssueDate;
		this.ExpiryDate = ExpiryDate;
		
	}
	
	//Getters
	public String getPassportNum() {
		return PassportNum;
	}
	
	public String getNationality() {
		return Nationality;
	}
	
	public Date getIssueDate() {
		return IssueDate;
	}
	
	public Date getExpiryDate() {
		return ExpiryDate;
	}
	
	//Relationship with Class Person
	@ManyToOne Person person;
	
}
