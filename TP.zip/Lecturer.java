

import java.util.*;
import javax.persistence.*;

@Entity
public class Lecturer {
	
	//Define Attributes
	
	@Id private String LecturerId;
	
	private String Room;
	private float Salary;
	private Date JoinDate;
	private String Qualification;
	
	//Constructor
	
	public Lecturer(String LecturerId,String Room,float Salary,String Qualification) {
		this.LecturerId = LecturerId;
		this.Room = Room;
		Salary = Salary;
		this.JoinDate = JoinDate;
		this.Qualification = Qualification;		
	}
	
	//getters
	public String getRoom() {
		return Room;
	}
	
	public float getSalary() {
		return Salary;
	}
	
	public Date getJoinDate() {
		return JoinDate;
	}
	
	public String getQualification() {
		return Qualification;
	}
	
	//Methode
	
	public boolean teachModule() {
		return true;
	}
	
//Relationship with Person, Module, Student and Department
		@ManyToOne Person person;
		@ManyToOne Module module;
		@ManyToOne Student student;
		@ManyToOne Department department;
		
	
	
	
}
